/* CH24 — shared across all pages: product data, pair state, bag count,
   flip-box open/close, WhatsApp float, newsletter. */

/* pulled from the printed packaging (box back panel) */
const CH24_WA = "919196036665";
const CH24_URL = "https://ch24.in";
const CH24_EMAIL = "help@ch24.in";

const CH24_PRODUCTS = {
  ocean:     { name: "Ocean Rush",      tone: "#61D6C4", toneName: "Aqua Notes", ink: "#0A0A0A", notes: "Aqua Notes · Jasmine · Patchouli", perfectFor: "Office · Day · Gym",        mood: "office", img: "assets/products/product-ocean-rush.jpg" },
  pistachio: { name: "Nutty Pistachio", tone: "#85AF67", toneName: "Pistachio",  ink: "#0A0A0A", notes: "Pistachio · Almond · Woody",       perfectFor: "Day Out · Party · Movie",   mood: "party",  img: "assets/products/product-nutty-pistachio.jpg" },
  vanilla:   { name: "Vanilla Bean",    tone: "#E9C7AC", toneName: "Vanilla",    ink: "#0A0A0A", notes: "Vanilla · Amber · Warm Spice",     perfectFor: "Date · Coffee · Evening",   mood: "date",   img: "assets/products/product-vanilla-bean.jpg" },
  oud:       { name: "Oud Affair",      tone: "#533C2C", toneName: "Oud",       ink: "#FFFFFF", notes: "Agarwood · Oud · Vanilla",         perfectFor: "Night · Evening · Wedding", mood: "night",  img: "assets/products/product-oud-affair.jpg" }
};

const PAIR_KEY = "ch24-pair";

const getPair = () => {
  try { return JSON.parse(localStorage.getItem(PAIR_KEY)) || []; }
  catch { return []; }
};
const setPair = (pair) => {
  localStorage.setItem(PAIR_KEY, JSON.stringify(pair));
  renderPair();
};

function renderPair() {
  const pair = getPair();
  document.querySelectorAll("[data-cart-count]").forEach(el => el.textContent = pair.length);

  const namesEl = document.querySelector("[data-pair-names]");
  if (namesEl) {
    namesEl.textContent = pair.length
      ? ": " + pair.map(id => CH24_PRODUCTS[id].name).join(" + ")
      : ": pick two";
  }
  const ctaEl = document.querySelector("[data-pair-cta]");
  if (ctaEl) ctaEl.setAttribute("aria-disabled", pair.length === 2 ? "false" : "true");

  document.querySelectorAll(".box[data-id]").forEach(card => {
    card.classList.toggle("is-picked", pair.includes(card.dataset.id));
  });
}

function togglePick(id) {
  const pair = getPair();
  const idx = pair.indexOf(id);
  if (idx > -1) pair.splice(idx, 1);
  else {
    if (pair.length === 2) pair.shift();
    pair.push(id);
  }
  setPair(pair);
}

/* .box__pick lives in a sibling .box__info, not inside .box itself, so it
   can't be found via ".box .box__pick" — read the id off the .box that
   immediately precedes .box__info instead */
function wireBoxPickButtons(root = document) {
  root.querySelectorAll(".box__pick").forEach(btn => {
    if (btn.dataset.wired) return;
    const info = btn.closest(".box__info");
    if (!info) return;
    const box = info.previousElementSibling?.classList.contains("box")
      ? info.previousElementSibling
      : info.previousElementSibling?.querySelector(".box");
    if (!box || !box.dataset.id) return;
    btn.dataset.wired = "1";
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      togglePick(box.dataset.id);
    });
  });
}
wireBoxPickButtons();

/* Click logic for the box cards:
   On desktop, clicking the box navigates to the product detail page.
   On mobile, the first tap opens the box to reveal the stick. If it's already open, tapping again navigates. */
document.addEventListener("click", (e) => {
  const box = e.target.closest(".box[data-id]");
  if (!box) return;
  if (e.target.closest(".box__pick")) return;

  const id = box.dataset.id;
  if (!id) return;

  const touchCapable = window.matchMedia("(hover: none)").matches;
  if (touchCapable) {
    const isOpen = box.classList.contains("is-open");
    if (isOpen) {
      // Let it naturally navigate (browser follows anchor href)
    } else {
      e.preventDefault();
      document.querySelectorAll(".box.is-open").forEach(b => b !== box && b.classList.remove("is-open"));
      box.classList.add("is-open");
    }
  }
});

renderPair();

/* "surprise me" — picks two different scents at random, does not fabricate
   any claim about them (no fake "bestseller"/"most loved" labels) */
document.querySelectorAll("[data-shuffle]").forEach(btn => {
  btn.addEventListener("click", () => {
    const ids = Object.keys(CH24_PRODUCTS);
    const a = ids[Math.floor(Math.random() * ids.length)];
    let b = ids[Math.floor(Math.random() * ids.length)];
    while (b === a) b = ids[Math.floor(Math.random() * ids.length)];
    btn.classList.add("is-spinning");
    setPair([a, b]);
    setTimeout(() => btn.classList.remove("is-spinning"), 500);
  });
});

/* WhatsApp order link for the current pair */
function pairWaLink() {
  const pair = getPair();
  const scents = pair.map(id => CH24_PRODUCTS[id].name).join(" + ");
  const msg = pair.length === 2
    ? `hi CH24 — I want Take Me Out Pack 01: ${scents} (₹499)`
    : "hi CH24 — I want to order Take Me Out";
  return `https://wa.me/${CH24_WA}?text=${encodeURIComponent(msg)}`;
}

/* Shopify Cart Integration: intercept pair checkout to add variant IDs dynamically */
document.addEventListener("click", (e) => {
  const cta = e.target.closest("[data-pair-cta]");
  if (!cta) return;
  if (cta.getAttribute("aria-disabled") === "true") {
    e.preventDefault();
    return;
  }

  if (window.CH24_SHOPIFY_VARIANTS) {
    e.preventDefault();
    const pair = getPair();
    if (pair.length !== 2) return;

    const variantId1 = window.CH24_SHOPIFY_VARIANTS[pair[0]];
    const variantId2 = window.CH24_SHOPIFY_VARIANTS[pair[1]];

    if (!variantId1 || !variantId2) {
      console.warn("Product variant mappings missing in CH24_SHOPIFY_VARIANTS");
      return;
    }

    // Clear cart first, then add selected pair variants
    fetch('/cart/clear.js', { method: 'POST' })
      .then(() => {
        return fetch('/cart/add.js', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            items: [
              { id: parseInt(variantId1), quantity: 1 },
              { id: parseInt(variantId2), quantity: 1 }
            ]
          })
        });
      })
      .then(res => res.json())
      .then(() => {
        window.location.href = '/checkout';
      })
      .catch(err => {
        console.error("Shopify checkout redirect error:", err);
        window.location.href = '/cart';
      });
  }
});

/* newsletter */
const nlForm = document.querySelector(".footer__form");
if (nlForm) nlForm.addEventListener("submit", (e) => {
  e.preventDefault();
  e.target.innerHTML = '<p class="footer__hook">You\'re on the list.</p>';
});

/* mood strip: click a mood → opens + highlights the matching box and
   scrolls to it, picks it as the first pair choice */
/* touch/no-hover devices: tap a panel to fold the row onto it (CSS
   handles the fold on :hover for mouse users, this covers the rest) */
if (window.matchMedia("(hover: none)").matches) {
  document.querySelectorAll("[data-panel]").forEach(panel => {
    panel.addEventListener("click", (e) => {
      if (e.target.closest(".mood__cta")) return;
      const wasActive = panel.classList.contains("is-active");
      document.querySelectorAll(".mood__panel.is-active").forEach(p => p !== panel && p.classList.remove("is-active"));
      panel.classList.toggle("is-active", !wasActive);
    });
  });
}

document.querySelectorAll("[data-mood-pick]").forEach(tile => {
  tile.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    const id = tile.dataset.moodPick;
    const pair = getPair().filter(x => x !== id);
    pair.unshift(id);
    setPair(pair.slice(0, 2));

    const box = document.querySelector(`.box[data-id="${id}"]`);
    if (box) {
      box.scrollIntoView({ behavior: "smooth", block: "center" });
      document.querySelectorAll(".box.is-open").forEach(b => b !== box && b.classList.remove("is-open"));
      box.classList.add("is-open");
      setTimeout(() => box.classList.remove("is-open"), 2200);
    } else {
      window.location.href = "/collections/all";
    }
  });
});
